# SeeColor-Extension
This is the extension version of the SeeColor Project (Link: https://github.com/Cookiefied/SeeColor)

Github: https://github.com/Cookiefied/SeeColor-Extension/tree/Firefox

Trello Host: https://trello.com/b/OPUeN6JI/

WARNING:: As of manifest v3 firefox does not allow cross-scripting and so this extension has to be enabled by bypassing multiple content security policies within firefox developer settings. Bypassing these settings is not recommended and can cause serious danger!!

## Install Instructions
First, download the extension by clicking the green "<> Code" button, then click "Download ZIP"\

Second, extract the downloaded zip file

Third, open about:addons in your firefox developer mode browser

Fourth, click the gear icon to open the "Debug Addons" button

Fifth, on the debug addons screen select "Load Temporary Add-on..."

Sixth, navigate to the location of the "manifest.json" file for the extension and double click

Seventh, the add-on will be loaded and ready to go, but the extension must be manually enabled for each site as the extension is not safe by firefox developer security settings